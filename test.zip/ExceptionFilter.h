#pragma once
#ifndef __PLATFORM_EXCEP_DUMP_H_
#define __PLATFORM_EXCEP_DUMP_H_
 void initExceptionDump();
#endif

